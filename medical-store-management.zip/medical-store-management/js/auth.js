// Login logic (demo authentication only)
if(load('msm_session',null))location.replace('dashboard.html');
$('#showpw').onchange=e=>{$('#pw').type=e.target.checked?'text':'password'};
$('#go').onclick=()=>{
  const e=$('#email').value.trim(),p=$('#pw').value,msg=$('#msg');msg.className='msg';
  if(!e||!p){msg.textContent='Please enter email and password.';return}
  if(!/^\S+@\S+\.\S+$/.test(e)){msg.textContent='Enter a valid email address.';return}
  $('#go').textContent='Signing in...';$('#go').disabled=true;
  setTimeout(()=>{
    if(e==='admin@medstore.demo'&&p==='admin123'){msg.className='msg ok';msg.textContent='Success! Redirecting...';save('msm_session',{name:'Admin (Demo)',email:e});setTimeout(()=>location.href='dashboard.html',500)}
    else{msg.textContent='Invalid email or password.';$('#go').textContent='Login';$('#go').disabled=false}
  },800);
};
