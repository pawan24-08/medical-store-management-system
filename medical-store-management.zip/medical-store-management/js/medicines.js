// Medicine CRUD, search, filter, sort
document.addEventListener('DOMContentLoaded',()=>{
  let meds=load('msm_meds',[]),editId=null,sortK='id',asc=true;
  const F=['id','name','cat','mfr','batch','pp','sp','qty','min','exp','sup'];
  const clear=()=>{F.forEach(k=>$('#f_'+k).value='');editId=null;$('#f_id').disabled=false;$('#ftitle').textContent='Add medicine';$('#err').textContent=''};
  function render(){
    const q=$('#q').value.toLowerCase(),fs=$('#fs').value;
    let list=meds.filter(m=>(m.name.toLowerCase().includes(q)||m.id.toLowerCase().includes(q))&&(!fs||medStatus(m)===fs));
    list.sort((a,b)=>(a[sortK]>b[sortK]?1:-1)*(asc?1:-1));
    const L={ok:'In stock',low:'Low stock',exp:'Expired'};
    $('#rows').innerHTML=list.map(m=>`<tr><td>${m.id}</td><td>${m.name}</td><td>${m.cat}</td><td>${m.qty}</td><td>${inr(m.sp)}</td><td>${m.exp}</td><td><span class="tag ${medStatus(m)}">${L[medStatus(m)]}</span></td>
    <td><button class="btn ghost" data-e="${m.id}">Edit</button> <button class="btn red" data-d="${m.id}">Delete</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty">No medicines match.</td></tr>';
  }
  $('#save').onclick=()=>{
    const v={};F.forEach(k=>v[k]=$('#f_'+k).value.trim());const err=$('#err');
    if(!v.id||!v.name||!v.cat||!v.exp)return err.textContent='ID, name, category and expiry are required.';
    if(!(+v.pp>=0&&v.pp!==''&&+v.sp>=0&&v.sp!==''))return err.textContent='Enter valid prices.';
    if(+v.sp<+v.pp)return err.textContent='Selling price is below purchase price.';
    if(!(Number.isInteger(+v.qty)&&+v.qty>=0&&v.qty!==''&&+v.min>=0))return err.textContent='Quantity/min stock must be whole numbers ≥ 0.';
    if(!editId&&meds.some(m=>m.id===v.id))return err.textContent='This ID already exists.';
    const m={id:v.id,name:v.name,cat:v.cat,mfr:v.mfr,batch:v.batch,pp:+v.pp,sp:+v.sp,qty:+v.qty,min:+v.min,exp:v.exp,supplier:v.sup};
    meds=editId?meds.map(x=>x.id===editId?m:x):[...meds,m];save('msm_meds',meds);toast('Medicine saved');clear();render();
  };
  $('#cancel').onclick=clear;$('#q').oninput=render;$('#fs').onchange=render;
  document.querySelectorAll('th[data-k]').forEach(th=>th.onclick=()=>{asc=sortK===th.dataset.k?!asc:true;sortK=th.dataset.k;render()});
  $('#rows').onclick=e=>{
    const d=e.target.dataset.d,ed=e.target.dataset.e;
    if(d&&confirm('Delete this medicine?')){meds=meds.filter(m=>m.id!==d);save('msm_meds',meds);toast('Deleted');render()}
    if(ed){const m=meds.find(x=>x.id===ed);editId=ed;F.forEach(k=>$('#f_'+k).value=(k==='sup'?m.supplier:m[k])??'');$('#f_id').disabled=true;$('#ftitle').textContent='Edit medicine';scrollTo(0,0)}
  };
  render();
});
