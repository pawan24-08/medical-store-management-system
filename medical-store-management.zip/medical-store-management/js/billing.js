// Billing: cart, totals, stock validation, invoice
document.addEventListener('DOMContentLoaded',()=>{
  let cart=[],busy=false;$('#tr').textContent=TAX_RATE;
  const meds=()=>load('msm_meds',[]);
  function totals(){const sub=cart.reduce((s,i)=>s+i.qty*i.price,0),d=Math.min(100,Math.max(0,+$('#disc').value||0)),dv=sub*d/100,tx=(sub-dv)*TAX_RATE/100;return{sub,dv,tx,tot:sub-dv+tx}}
  function render(){
    const q=$('#q').value.toLowerCase();
    $('#list').innerHTML=meds().filter(m=>m.name.toLowerCase().includes(q)).map(m=>`<tr><td>${m.name}<br><span class="note">Stock ${m.qty} • ${inr(m.sp)}</span></td><td>${medStatus(m)==='exp'?'<span class="tag exp">Expired</span>':`<button class="btn" data-a="${m.id}">Add</button>`}</td></tr>`).join('')||'<tr><td class="empty">No results</td></tr>';
    $('#cart').innerHTML=cart.map(i=>`<tr><td>${i.name}</td><td><button class="btn ghost" data-m="${i.id}">−</button> ${i.qty} <button class="btn ghost" data-p="${i.id}">+</button></td><td>${inr(i.qty*i.price)}</td><td><button class="btn red" data-r="${i.id}">✕</button></td></tr>`).join('')||'<tr><td class="empty">Cart is empty</td></tr>';
    const t=totals();$('#sub').textContent=inr(t.sub);$('#dv').textContent='-'+inr(t.dv);$('#tx').textContent=inr(t.tx);$('#tot').textContent=inr(t.tot);
  }
  document.body.onclick=e=>{
    const d=e.target.dataset;if(!d)return;
    if(d.a){const m=meds().find(x=>x.id===d.a),c=cart.find(x=>x.id===d.a);
      if(m.exp<dayStr(0))return toast('Expired medicine cannot be sold',1);
      if((c?c.qty:0)+1>m.qty)return toast('Not enough stock',1);
      c?c.qty++:cart.push({id:m.id,name:m.name,qty:1,price:m.sp});render()}
    if(d.p){const c=cart.find(x=>x.id===d.p);if(c.qty+1>meds().find(x=>x.id===d.p).qty)return toast('Not enough stock',1);c.qty++;render()}
    if(d.m){const c=cart.find(x=>x.id===d.m);c.qty--;if(c.qty<1)cart=cart.filter(x=>x!==c);render()}
    if(d.r){cart=cart.filter(x=>x.id!==d.r);render()}
  };
  $('#q').oninput=render;$('#disc').oninput=render;
  $('#co').onclick=()=>{
    if(busy)return;if(!cart.length)return toast('Cart is empty',1);busy=true;
    const all=meds();
    for(const i of cart){const m=all.find(x=>x.id===i.id);if(!m||m.exp<dayStr(0)||m.qty<i.qty){busy=false;return toast('Stock/expiry problem: '+i.name,1)}}
    cart.forEach(i=>all.find(x=>x.id===i.id).qty-=i.qty);save('msm_meds',all);
    const sales=load('msm_sales',[]),t=totals();
    const s={inv:'INV-'+(1001+sales.length+Math.floor(Math.random()*900)),date:new Date().toISOString(),customer:$('#cust').value.trim()||'Walk-in',items:cart,subtotal:t.sub,discount:t.dv,tax:t.tx,total:t.tot,pay:$('#pay').value};
    sales.push(s);save('msm_sales',sales);
    const inv=$('#invoice');inv.hidden=false;
    inv.innerHTML=`<h2>Invoice ${s.inv}</h2><p>${s.date.slice(0,16).replace('T',' ')} • ${s.customer} • ${s.pay}</p><table>${s.items.map(i=>`<tr><td>${i.name}</td><td>${i.qty} × ${inr(i.price)}</td><td>${inr(i.qty*i.price)}</td></tr>`).join('')}</table>
    <p>Subtotal ${inr(s.subtotal)} | Discount ${inr(s.discount)} | Demo tax ${inr(s.tax)}<br><b>Total ${inr(s.total)}</b></p><button class="btn noprint" id="pr">Print Invoice</button>`;
    $('#pr').onclick=()=>window.print();
    cart=[];toast('Sale completed');render();busy=false;
  };
  render();
});
