// Shared helpers: storage, demo data, auth guard, sidebar, theme, toast
const $=(s,r=document)=>r.querySelector(s);
const load=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v??d}catch{return d}};
const save=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const inr=n=>'₹'+Number(n||0).toFixed(2);
const dayStr=o=>{const d=new Date();d.setDate(d.getDate()+o);return d.toISOString().slice(0,10)};
const TAX_RATE=5; // DEMO tax rate (%) - not a legally correct pharmacy tax

function seed(){
  if(localStorage.msm_meds)return;
  const m=(id,name,cat,pp,sp,q,min,exp)=>({id,name,cat,mfr:'DemoPharma',batch:'B'+id.slice(-3),pp,sp,qty:q,min,exp,supplier:'Demo Supplies'});
  save('msm_meds',[m('MED001','Paracetamol 500mg','Pain Relief',1.2,2,120,30,dayStr(400)),m('MED002','Amoxicillin 250mg','Antibiotic',4,7.5,18,25,dayStr(200)),
  m('MED003','Cetirizine 10mg','Allergy',1.5,3,80,20,dayStr(25)),m('MED004','Vitamin C 500mg','Vitamin',2,4,60,20,dayStr(300)),
  m('MED005','Cough Syrup 100ml','Cold & Cough',35,60,40,10,dayStr(-10)),m('MED006','Antacid Gel','Digestive',20,35,9,15,dayStr(150)),
  m('MED007','Ibuprofen 400mg','Pain Relief',2,4,90,25,dayStr(500)),m('MED008','ORS Sachet','Digestive',8,15,70,20,dayStr(350))]);
  save('msm_sales',[1,2,3,4,5].map(i=>({inv:'INV-'+(1000+i),date:new Date(Date.now()-(6-i)*864e5).toISOString(),customer:['Asha Demo','Ravi Sample','Walk-in','Meera Test','Walk-in'][i-1],
    items:[{id:'MED001',name:'Paracetamol 500mg',qty:i,price:2},{id:'MED004',name:'Vitamin C 500mg',qty:2,price:4}],subtotal:2*i+8,discount:0,tax:+((2*i+8)*TAX_RATE/100).toFixed(2),total:+((2*i+8)*(1+TAX_RATE/100)).toFixed(2),pay:['Cash','UPI','Card'][i%3]})));
}
function toast(msg,err){let c=$('#toasts');if(!c){c=document.createElement('div');c.id='toasts';document.body.appendChild(c)}
  const t=document.createElement('div');t.className='toast'+(err?' error':'');t.textContent=msg;c.appendChild(t);setTimeout(()=>t.remove(),3000)}
function medStatus(m){if(m.exp<dayStr(0))return'exp';if(m.qty<=m.min)return'low';return'ok'}

seed();
document.documentElement.dataset.theme=load('msm_theme','light');
const page=document.body.dataset.page;
if(page!=='login'){
  const user=load('msm_session',null);
  if(!user){location.replace('index.html')}
  else document.addEventListener('DOMContentLoaded',()=>{
    const links=[['dashboard','Dashboard'],['medicines','Medicines'],['billing','Billing']];
    $('aside').innerHTML='<h2>💊 MediStore</h2>'+links.map(l=>`<a href="${l[0]}.html" class="${l[0]===page?'active':''}">${l[1]}</a>`).join('')+'<a href="#" id="logout">Logout</a>';
    $('#top').innerHTML=`<div><button class="btn ghost" id="menu">☰</button> <h1 style="display:inline">${document.title}</h1></div><div><span class="note">${user.name}</span> <button class="btn ghost" id="theme">🌓</button></div>`;
    $('#menu').onclick=()=>$('.layout').classList.toggle('collapsed');
    $('#theme').onclick=()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;save('msm_theme',t)};
    $('#logout').onclick=e=>{e.preventDefault();if(confirm('Log out?')){localStorage.removeItem('msm_session');location.href='index.html'}};
  });
}
