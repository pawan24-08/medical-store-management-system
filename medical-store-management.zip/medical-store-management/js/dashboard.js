// Dashboard: all figures calculated from stored data
document.addEventListener('DOMContentLoaded',()=>{
  const meds=load('msm_meds',[]),sales=load('msm_sales',[]),today=dayStr(0);
  const sum=a=>a.reduce((s,x)=>s+x.total,0);
  const stats=[['Total Sales',inr(sum(sales))],["Today's Sales",inr(sum(sales.filter(s=>s.date.slice(0,10)===today)))],['Total Medicines',meds.length],
   ['Low Stock',meds.filter(m=>medStatus(m)==='low').length],['Expired',meds.filter(m=>medStatus(m)==='exp').length],['Total Orders',sales.length],
   ['Inventory Value',inr(meds.reduce((s,m)=>s+m.pp*m.qty,0))]];
  $('#cards').innerHTML=stats.map(s=>`<div class="card"><small>${s[0]}</small><b>${s[1]}</b></div>`).join('');
  const al=meds.filter(m=>medStatus(m)!=='ok'||m.exp<=dayStr(30)).map(m=>`<li>${m.name}: ${medStatus(m)==='exp'?'EXPIRED':m.exp<=dayStr(30)?'expires '+m.exp:'low stock ('+m.qty+')'}</li>`);
  $('#alerts').innerHTML=al.join('')||'<li>No alerts 🎉</li>';
  $('#recent').innerHTML=sales.slice(-8).reverse().map(s=>`<tr><td>${s.inv}</td><td>${s.customer}</td><td>${s.date.slice(0,10)}</td><td>${s.items.length}</td><td>${s.pay}</td><td>${inr(s.total)}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">No sales yet</td></tr>';
  const days=[...Array(7)].map((_,i)=>dayStr(i-6));
  if(window.Chart)new Chart($('#chart'),{type:'bar',data:{labels:days.map(d=>d.slice(5)),datasets:[{label:'Sales (₹)',backgroundColor:'#0e9aa7',data:days.map(d=>sum(sales.filter(s=>s.date.slice(0,10)===d)))}]}});
  $('#reset').onclick=()=>{if(confirm('Reset ALL demo data?')){['msm_meds','msm_sales'].forEach(k=>localStorage.removeItem(k));location.reload()}};
});
